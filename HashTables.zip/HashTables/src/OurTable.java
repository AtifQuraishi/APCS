//import java.util.ArrayList;
//
//public class OurTable {
//    ArrayList<String> keys = new ArrayList<>();
//    ArrayList<Integer> values = new ArrayList<>();
//
//    public void put (String names, Integer val){
//        keys.add(names);
//        values.add(val);
//    }
//
//    public Integer get (String names){
//        for (int i = 0; i < keys.size(); i++) {
//            if (names.equals(keys.get(i))){
//                return values.get(i);
//            }
//        }
//        return null;
//    }
//
//
//
//    public int hash(String in, int n) {
//        long hash = 0;
//        for (int i = 0; i < in.length(); i++) {
//            hash = (hash * 31) + (int)in.charAt(i);
//        }
//
//        return (int)(hash % n);
//    }
//
//}
