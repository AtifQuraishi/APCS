public class Main {
    public static void main(String[] args) {

        HashList map = new HashList();
        map.put("David", "42");
        map.put("Nadia", "5");
        map.put("Grandama", "78");


        Integer age1 = map.get("David");
        Integer age2 = map.get("Obama");

        System.out.println(age1);
    }
}
