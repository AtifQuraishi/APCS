import java.util.ArrayList;

public class HashList {

    private HashList h1 = new HashList();
    private Entry[] arr = new Entry[100];

    public void put (String key, String value){
         Entry e = new Entry(key, value);
         int index = h1=(key);
         arr[index]= e;
    }


    public String get (String key){
        int index = (key);
        Entry e = arr[index];

        if (e == null) return null;
        return e.getValue();
    }
}
